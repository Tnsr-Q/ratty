# Problem Solver Skill

A Claude Code skill for systematic problem diagnosis and solution evaluation using progressive disclosure.

## What it does

Provides 7 analytical frameworks for diagnosing root causes and evaluating solutions:

| Problem Signal | Framework |
|---|---|
| Unknown root cause, simple chain | Five Whys |
| Conflicting requirements / trade-offs | TRIZ |
| Slow throughput / capacity issue | Theory of Constraints |
| Recurring / interconnected issues | Systems Thinking |
| Multi-factor quality issue | Ishikawa / Fishbone |
| Critical incident, high stakes | Root Cause Analysis |
| Comparing multiple solutions | Solution Evaluation Matrix |

## Progressive disclosure pattern

The main `SKILL.md` is only ~55 lines. It contains just the routing table and workflow. Each framework's details live in separate `references/` files that load on-demand.

This means the agent only reads what it needs for the current problem, instead of loading all 7 frameworks every time.

```
SKILL.md                              # routing + workflow (~55 lines)
references/
  five-whys.md                        # loaded when simple cause-effect
  triz.md                             # loaded when technical contradictions
  theory-of-constraints.md            # loaded when throughput/bottleneck
  systems-thinking.md                 # loaded when feedback loops
  ishikawa.md                         # loaded when multi-factor quality
  root-cause-analysis.md              # loaded when critical/high-stakes
  solution-matrix.md                  # loaded when comparing solutions
```

## Installation

Copy `SKILL.md` and the `references/` directory into your Claude Code skills folder:

```bash
# Clone and copy
git clone https://github.com/cathrynlavery/problem-solver-skill.git
cp -r problem-solver-skill/ ~/.claude/skills/problem-solver/

# Or just the files
mkdir -p ~/.claude/skills/problem-solver/references
curl -o ~/.claude/skills/problem-solver/SKILL.md https://raw.githubusercontent.com/cathrynlavery/problem-solver-skill/main/SKILL.md
# ... and each reference file
```

## About

Built by [founder.codes](https://founder.codes) — AI-native tools for founders who build with agents.

## License

MIT
