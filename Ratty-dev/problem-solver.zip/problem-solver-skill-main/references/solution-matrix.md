# Solution Evaluation Matrix

Objectively score and compare solution options against weighted criteria.

## Process

1. **List candidate solutions** (all viable options)
2. **Define criteria**: Impact, Effort, Risk, Cost, Time, Strategic alignment
3. **Weight criteria** (assign relative importance, totaling 100%)
4. **Score each solution** (1-5 or 1-10 per criterion)
5. **Calculate weighted totals** (score x weight for each)
6. **Select highest-scoring** (consider sensitivity analysis)

## Example

| Solution | Impact (40%) | Effort (30%) | Risk (20%) | Cost (10%) | Total |
|----------|-------------|-------------|-----------|-----------|-------|
| A        | 8 (3.2)     | 4 (1.2)     | 7 (1.4)   | 6 (0.6)   | 6.4   |
| B        | 6 (2.4)     | 8 (2.4)     | 9 (1.8)   | 9 (0.9)   | 7.5   |

## Common Pitfall

Avoid selecting solutions based on ease alone. Balance effort with impact.

## Best For

Choosing between multiple viable solutions, stakeholder alignment, justifying decisions with objective criteria.
