# Five Whys

Quick root cause drilling through iterative questioning.

## Process

Ask "why" five times, each answer becoming the basis for the next question.

## Example

- Problem: Sales dropped
- Why? Fewer leads came in
- Why? Marketing campaign was paused
- Why? Budget was reallocated
- Why? Company shifted priorities to product development
- Why? Market research showed product-market fit issues

## Best For

Rapid diagnosis, simple cause-effect chains, initial investigation.

## Limitations

May oversimplify problems with multiple root causes. Works best for linear cause-effect relationships. If you find branching causes, escalate to Ishikawa or full RCA.
