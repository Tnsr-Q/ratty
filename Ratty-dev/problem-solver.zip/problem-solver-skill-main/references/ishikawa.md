# Ishikawa / Fishbone Diagram

Visual cause-effect mapping across standardized categories.

## Process

1. State the problem clearly (the "fish head")
2. Branch into major categories (the "bones"):
   - **Materials**: Raw materials, supplies, inputs
   - **Methods**: Processes, procedures, standards
   - **Machines**: Equipment, tools, technology
   - **Manpower**: People, skills, training
   - **Measurement**: Metrics, inspection, data quality
   - **Environment**: Context, conditions, external factors
3. For each category, drill into specific sub-causes
4. Investigate the most likely root causes

## Variations

- 4 Ms (Materials, Methods, Machines, Manpower) for manufacturing
- Adapt categories for services: Policies, Procedures, People, Plant/Technology

## Example

Problem: Website downtime. Categories: Methods (deployment lacks testing), Machines (server capacity insufficient), Measurement (monitoring alerts delayed).

## Best For

Quality issues, multi-factor analysis, team brainstorming, structured root cause exploration.
