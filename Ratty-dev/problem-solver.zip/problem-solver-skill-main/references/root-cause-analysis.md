# Root Cause Analysis

Comprehensive investigation combining multiple analytical tools.

## Process

1. **Define** the problem precisely (what, where, when, extent, impact)
2. **Collect data** (logs, metrics, timelines, stakeholder input)
3. **Identify possible causes** (brainstorm using Fishbone, Five Whys)
4. **Analyze causes** (eliminate unlikely causes, look for patterns)
5. **Test hypotheses** (validate suspected root causes with evidence)
6. **Verify root cause** (confirm it directly produces the problem)
7. **Implement corrective actions** (address root cause, not symptoms)
8. **Monitor results** (track metrics to ensure resolution)

## Key Principles

- Focus on systemic causes, not blame
- Distinguish correlation from causation
- Look for multiple contributing causes
- Verify before declaring root cause

## Best For

Critical incidents, post-mortems, high-stakes problems where you must get it right.
