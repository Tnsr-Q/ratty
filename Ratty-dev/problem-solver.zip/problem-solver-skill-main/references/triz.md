# TRIZ (Theory of Inventive Problem Solving)

Resolve technical contradictions through inventive principles.

## Process

1. Identify the contradiction (improving parameter A worsens parameter B)
2. Consult inventive principles below for solution patterns
3. Adapt proven principles to your specific context

## Key Inventive Principles

- **Segmentation**: Divide into parts, make modular
- **Extraction**: Extract troubling parts or properties
- **Local quality**: Non-uniform structure where needed
- **Asymmetry**: Replace symmetrical with asymmetrical
- **Combining**: Combine identical or similar operations
- **Universality**: Parts perform multiple functions
- **Nesting**: Place objects inside each other
- **Counterweight**: Compensate with opposing forces
- **Prior action**: Perform changes in advance
- **Cushion in advance**: Prepare emergency means beforehand
- **Equipotentiality**: Eliminate need for lifting/lowering
- **Inversion**: Reverse actions or swap movable/stationary
- **Dynamics**: Optimize characteristics per operating stage
- **Partial or excessive action**: If 100% is hard, use slightly less or more

## Example

Making a product stronger (A) makes it heavier (B). Apply: segmentation (hollow structures), nesting (composite materials), or local quality (reinforce only stress points).

## Best For

Engineering challenges, design problems, technical trade-offs, conflicting requirements.
