# Systems Thinking

Understand interconnected problems with feedback loops and emergent behaviors.

## Process

1. **Map system boundaries** — what's inside/outside your system
2. **Identify components** and their relationships
3. **Find feedback loops**:
   - Reinforcing loops (virtuous/vicious cycles — growth or decline that accelerates)
   - Balancing loops (self-correcting mechanisms that resist change)
4. **Recognize delays** — time lags between cause and effect (often causes overreaction)
5. **Identify leverage points** — where small changes create large effects
6. **Model interventions** and predict system responses

## Common Archetypes

- "Fixes that fail" — short-term fix worsens root cause
- "Shifting the burden" — symptomatic solution weakens fundamental solution
- "Limits to growth" — reinforcing loop hits a balancing constraint

## Example

Customer churn increases → Support team overloaded → Service quality drops → More churn (reinforcing loop). Leverage point: Proactive customer education reduces support load and improves retention.

## Best For

Complex problems with multiple factors, recurring issues, organizational challenges, situations where solutions create new problems.
