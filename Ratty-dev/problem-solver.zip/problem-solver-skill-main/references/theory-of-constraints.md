# Theory of Constraints

Identify and optimize system bottlenecks to maximize throughput.

## Five Focusing Steps

1. **Identify** the constraint (the bottleneck limiting system performance)
2. **Exploit** the constraint (maximize its efficiency without major investment)
3. **Subordinate** everything else (align all other processes to support the constraint)
4. **Elevate** the constraint (invest to increase its capacity)
5. **Repeat** (find the next constraint; don't let inertia become the constraint)

## Key Concepts

- Only one constraint exists at a time in a system
- Optimizing non-constraints doesn't improve system performance
- Local optimization often harms global throughput

## Example

Support team handles 100 tickets/day, but QA reviewer can only review 50/day. The constraint is QA review.
- **Exploit**: Train QA on faster review techniques
- **Subordinate**: Agents prioritize high-quality first-pass tickets
- **Elevate**: Add another QA reviewer

## Best For

Workflow problems, capacity planning, throughput optimization, service delivery chains.
